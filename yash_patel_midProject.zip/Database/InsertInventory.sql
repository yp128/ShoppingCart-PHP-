/*
--------------------
use the StoreCreator.sql first and then runthis file...
--------------------
*/

use yashPatelStore;

insert into products VALUES(null,'Socks','./uploads/Socks.jpg','Crew length socks stay up and hits at mid-calf.',10,2.99);
insert into products VALUES(null,'Shoes','./uploads/Shoes.jpg','Running Shoes Material: High Quality Synthetic Sole and Breathable Mesh Upper.',20,20.99);
insert into products VALUES(null,'Towel','./uploads/Towel.jpg','These luxurious washcloths are made of Supima cotton, which is grown in the U.S. and prized for fine, long-staple fibers that create a silky, soft feel.',10,12.99);
insert into products VALUES(null,'Hoodie','./uploads/Hoodie.jpg','SUPER COMFORTABLE – Our everyday classic mens hoodies are super comfortable and perfect for lounging around the house, running errands, working or going out for a run',10,22.99);
insert into products VALUES(null,'Kayak','./uploads/Kayak.jpg','Nimble, durable kayak is made of durable welded material with eye-catching graphics for added safety on the lake or slow-moving river',10,200.99);